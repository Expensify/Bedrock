gcc-7  -g -c -O2 -Wno-unused-but-set-variable -DSQLITE_ENABLE_STAT4 -DSQLITE_ENABLE_JSON1 -DSQLITE_ENABLE_SESSION -DSQLITE_ENABLE_PREUPDATE_HOOK -DSQLITE_ENABLE_UPDATE_DELETE_LIMIT ../libstuff/sqlite3.c;
g++-7 -g -c -O2 sqlite_standalone_parallel_test.cpp;
g++-7 -g -O2 -o sqlitetest sqlite_standalone_parallel_test.o sqlite3.o -ldl -lpthread;
